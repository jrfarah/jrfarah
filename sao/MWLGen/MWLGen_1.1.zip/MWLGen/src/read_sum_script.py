import sys
sys.path.insert(0, 'src/janus/src/')
# arg 1--hub dir, arg 2--source arg 3--path to sum files

import mergeDataset
import glob

start_times = []
end_times = []
dataset_objects = []

def get_start_and_end_times(_file, source):
	global start_times, end_times, dataset_objects
	dataset_objects.append(mergeDataset.extractFromSummary(_file, "/Users/jrfarah/Documents/eht/MWL_EHT_Coverage/2018/janus/legacy/weather", get_taus=False))

	relevant_object = dataset_objects[-1]

	# get the list of times and sources
	# print relevant_object.source

	indices = []
	# print source

	# get a list of all relevant indices
	for i, j in enumerate(relevant_object.source):
	    if j == str(source):
	       	indices.append(i)
	# print indices

	# get list of start times, end times, and days
	tmp_s = []
	tmp_e = []
	tmp_d = []
	for idx in indices:
		tmp_s.append(relevant_object.start_time[idx])
		tmp_e.append(relevant_object.end_time[idx])
		tmp_d.append(relevant_object.day[idx])

	# print tmp_s, tmp_e, tmp_d

	for i, day in enumerate(tmp_d):
		day = int(day)
		s_t = day+float(tmp_s[i])
		e_t = day+float(tmp_e[i])
		start_times.append(s_t)
		end_times.append(e_t)



# get the list of sum files
path_to_sum_files = sys.argv[3]
sum_files = glob.glob(path_to_sum_files+"/*.sum")


# begin going through each sum file:
for _file in sum_files:
	print _file
	get_start_and_end_times(_file, sys.argv[2])

print start_times, end_times

with open("{0}/EHT.csv".format(sys.argv[1]), "w") as eht:
	eht.write("Start, End\n")
	for i, start in enumerate(start_times):
		# if str(start) != str(end_times[i]):
		str_to_write = "{0}, {1}\n".format(start, end_times[i])
		eht.write(str_to_write)


# print start_times, end_times