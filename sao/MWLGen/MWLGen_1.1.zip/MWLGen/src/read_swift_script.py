# program to parse and edit the swift data

import datetime
import sys
# arg 1--hub dir arg 2--swift file dirs

def convert(dts):
	print dts
	day = datetime.datetime.strptime(dts.split()[0], "%Y-%m-%d")
	day = day.strftime('%j')
	time = dts.split()[1]
	time = time.split(":")
	hour = int(time[0])
	minute = int(time[1])
	frac = (hour+(minute/60.))/24.
	return float(day)+float(frac)

with open(str(sys.argv[2]), "r") as _swift:
	lines = _swift.readlines()

prestart = []
preend = []
for line in lines:
	prestart.append(line.split(',')[0].strip('\xc2\xa0'))
	preend.append(line.split(',')[1].strip('\xc2\xa0'))

del prestart[0]
del preend[0]
start = []
end = []
for date in prestart:
	try:
		start.append(convert(date))
	except IndexError:
		break


for date in preend:
	try:
		end.append(convert(date))
	except IndexError:
		break

with open("{0}/SWIFT.csv".format(sys.argv[1]), "w") as _new_swift:
	_new_swift.write("Start, End\n")
	for i, date in enumerate(start):
		_new_swift.write("{0}, {1}\n".format(str(date), str(end[i])))
