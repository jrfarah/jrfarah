# demo of mergeDataset
# written by Joseph Farah

import os
import sys
import pandas
import datetime
import math

import mergeDataset

# some default filepaths, for experimentation
summary_file = os.path.abspath("../legacy/sum/testa.sum")
# tau_file = os.path.abspath("../legacy/weather/ALMA10YR_8-8-17.dat")
tau_file = os.path.abspath("../legacy/weather")

# take the column headers and use them to identify the beginning
# of a section
section_delimiter = "SCAN  DAY START UT  SOURCE     TYPE  STATIONS    t => tape change"

# get the filepaths from arguments, if they exist:
if len(sys.argv) == 3:
	summary_file = os.path.abspath(sys.argv[1])
	tau_file = os.path.abspath(sys.argv[2])
	print "File arguments provided. Using: "

elif len(sys.argv) == 2:
	print "You did not provide enough arguments."
	sys.exit(1)

else:
	print "No file arguments provided. Using: "

print summary_file
print tau_file

merged_object = mergeDataset.extractFromSummary(summary_file, tau_file)

# print merged_object.tau

# let's try to recalculate the taus for a different day
merged_object.recalculate_taus(200)
print 'NEW TAUS CALCULATED FOR DAY 200 ======================================'
# print merged_object.tau
