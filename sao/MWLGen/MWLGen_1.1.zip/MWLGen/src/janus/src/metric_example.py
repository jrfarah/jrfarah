####### Editing Log
#Edited by Rodrigo on April 11th, trying to include more functionality on the opacity read in
#
#
#######
import os
import sys
import pandas
import datetime
import math

import mergeDataset

# some default filepaths, for experimentation
summary_file = os.path.abspath("../legacy/sum/testa.sum")
#tau_file = os.path.abspath("../legacy/weather/ALMA10YR_8-8-17.dat")
tau_file = os.path.abspath("../legacy/forecasts/20180418/")

# get the filepaths from arguments, if they exist:
if len(sys.argv) == 3:
	summary_file = os.path.abspath(sys.argv[1])
	tau_file = os.path.abspath(sys.argv[2])
	print "File arguments provided. Using: "

elif len(sys.argv) == 2:
	print "You did not provide enough arguments."
	sys.exit(1)

else:
	print "No file arguments provided. Using: "

print summary_file
print tau_file

merged_object = mergeDataset.extractFromSummary(summary_file, tau_file)

# Define site sensitivies in Jy
site_SEFD = {'ALMA':100, 'APEX':2000, 'PICOVEL':1000, 'SPT':5000, 'LMT':500, 'SMTO':5000, 'JCMT':5000, 'SMAP':3000, 'THULE':5000}

def Merit_1day(merged_object, BW = 4.e9, t_int = 10, sigma_min = 0.01):
    N_scan = len(merged_object.length)
    N_site = len(merged_object.site_order)

    # Get nominal SEFDs
    SEFD = [site_SEFD[s] for s in merged_object.site_order]

    M       = 0.0
    M_ideal = 0.0
    
    for j in range(N_scan): #scan iterator
        for site1 in range(N_site-1):
            if merged_object.station_elevation[j][site1] == '---': continue
            for site2 in range(site1+1,N_site):
                if merged_object.station_elevation[j][site2] == '---': continue

                SEFD1 = SEFD[site1] * math.exp(merged_object.tau[j][site1] / math.sin(float(merged_object.station_elevation[j][site1]))) 
                SEFD2 = SEFD[site2] * math.exp(merged_object.tau[j][site2] / math.sin(float(merged_object.station_elevation[j][site2])))
                sigma       = (SEFD1 * SEFD2 / (BW * t_int))**0.5
                sigma_ideal = (SEFD[site1] * SEFD[site2] / (BW * t_int))**0.5

                M       += (sigma_min / (sigma_min + sigma))       * merged_object.length[j]
                M_ideal += (sigma_min / (sigma_min + sigma_ideal)) * merged_object.length[j]
    return [M, M_ideal]

# Pass a list of [[merged_object1, UTday], [merged_object2, UTday], ...]
def Merit(sched, source_list=[], site_list=[]):
    # Calculate the merit function
    # Also calculate the ideal value

    M = 0.0

    for element in merged_object.length:
	    tdelta = math.fabs(element.seconds - 86400)
	    sum_length += float(tdelta)



# now can we call things from the merged object?
# lets try to sum over the lengths of all the scans
sum_length = 0
print merged_object.length
for element in merged_object.length:
	tdelta = math.fabs(element.seconds - 86400)
	sum_length += float(tdelta)

print sum_length
