####################################################################
# written by Joseph Farah @jrfarah on 3/30/18
# last edited by [Joseph Farah] [@jrfarah] on [3/30/18]
# Purpose: this program will try to read in the sum/tau files 
# and merge them into one data structure. precursor for the merge 
# function 
# Notes:
####################################################################

# package imports ##################################################
import os
import sys
import pandas
import datetime
import math
import glob
from numba import jit
from scipy import interpolate

section_delimiter = "SCAN  DAY START UT  SOURCE     TYPE  STATIONS    t => tape change"

# classes ##########################################################
class dataColumns(object):
	''' gathers all the data in one place '''

	def __init__(self, num_sections, expcode):

		# these are the attributes of the file! feel free to use them how you will
		# documentation for each attribute will hopefully come soon
		self.expcode = expcode
		self.site_order = []
		self.final_set = []
		self.scan_num = []
		self.day = []
		self.daytime_mixed = []
		self.start_time = []
		self.end_time = []
		self.length = []
		self.source = []
		self.station_elevation = []
		self.pre_focus_time = []
		self.tau = []
		# self.frequency = []
		self.list_of_lists = [
			self.daytime_mixed,
			self.length,
			self.source,
			self.station_elevation,
			self.pre_focus_time,
			self.tau
		]

		# attributes related to the tau files
		self.full_tau_info = []

	def merge(self, sn, d, st, et, so, stel, pft):
		''' will merge all the datasets into one '''
		self.final_set = [
			# self.scan_num,
			self.day,
			self.start_time,
			self.end_time,
			self.source,
			self.station_elevation,
			self.pre_focus_time
		]

		return self.final_set

	@jit
	def get_all_taus(self, directory):
		for site in self.site_order:
			self.full_tau_info.append(fullTauInfo(glob.glob(str(directory)+"/*" + site.upper() + "*")[0]))

		for site_tau in self.full_tau_info:
			site_tau.get_interpolation_function()

		print self.full_tau_info


	def date_to_nth_day(self, date, format='%Y%m%d'):
	    date = pandas.to_datetime(date, format=format)
	    new_year_day = pandas.Timestamp(year=date.year, month=1, day=1)
	    return (date - new_year_day).days + 1

	def nth_day_to_date(self, day, year=2012):
		return datetime.datetime(year, 1, 1) + datetime.timedelta(day - 1)

	def get_opacity_and_frequency(self, mixed_date, interpf):
		# print interpf
		return interpf([mixed_date])

	# def get_interpolated_tau(interp_func, ):

	def cycle_through_station_opacities(self, mixed_date):
		taus = []
		for site in self.site_order:
			tau_set = self.full_tau_info[self.site_order.index(site)]
			# taus.append(self.get_opacity_and_frequency(mixed_date, tau_set.interpolation_function))
			print mixed_date
			taus.append(float(tau_set.interpolation_function(float(mixed_date))))

		return taus

	def recalculate_taus(self, new_year_day):
		print "LENGTH BEFORE: ", len(self.tau)
		self.tau = []
		# print new_year_day
		nyd = float(new_year_day)/365.
		# print nyd 
		# print self.daytime_mixed
		for date in self.daytime_mixed:
			# print "Date: ", date
			diff = (nyd - float(date) % 1)
			# print "Diff: ", diff
			new_date = float(date) + diff
			# print "New date: ", new_date
			tau_list = self.cycle_through_station_opacities(new_date)
			self.tau.append(tau_list)
		print "LENGTH AFTER: ", len(self.tau)

	def show_all(self):
		'''prints the entire dataset'''
		print self.day,
		print self.start_time,
		print self.end_time,
		print self.source,
		print self.station_elevation,
		print self.pre_focus_time

	def write_to_file(self, column_headers, filename):
		''' makes a better sum file '''
		with open(filename, "w") as _file:
			_file.write("# EXPCODE: " + str(self.expcode) + "\n")
			_file.write("#" + str(column_headers)+"\n")
			_file.write("# SITES: "+ str(self.site_order)+"\n")
			for index in range(0,len(self.day)-1):
				valve = []
				for l in self.list_of_lists:
					valve.append(l[index])
				# print valve
				_file.write(str(valve)+"\n")



class fullTauInfo(object):

	def __init__(self, filepath):

		self.interpolation_function = None
		self.interpx = []
		self.interpy = []

		with open(filepath, "r") as _taufile:
			self.tau_file_lines = _taufile.readlines()

		for entry in self.tau_file_lines:
			if self.tau_file_lines.index(entry) == 0:
				continue
			valve = str(float(entry.split()[0][0:4])+(float(date_to_nth_day(entry.split()[0]))+float(entry.split()[1])/24.)/365.)
			entry.split()[1] = valve
			self.interpx.append(float(valve))
			self.interpy.append(float(entry.split()[-2]))

	@jit
	def get_interpolation_function(self):
		print max(self.interpx), type(min(self.interpx))
		self.interpolation_function = interpolate.interp1d(self.interpx, self.interpy)

# functions ############################################################

@jit
def extractFromSummary(summary_file, tau_directory):
	with open(summary_file, "r") as sumfile:
		sum_lines = sumfile.readlines()

	# get the order of the sites
	site_order = []
	for line in sum_lines:
		if line[0:8] == "STATIONS":
			print "Found"
			index = sum_lines.index(line)
			index+=5
			print len(sum_lines[index].split())
			while len(sum_lines[index].split()) == 9:
				site_order.append(sum_lines[index].split()[0])
				index+=1
	print site_order

	section_starts = []
	for line_num in range(0, len(sum_lines)-1):
		line = sum_lines[line_num]
		if line[0:4] == "SCAN":
			section_starts.append(line_num)

	print "Number of data sections:", len(section_starts)
	print section_starts

	# create new instance of the final dataset
	sumDataset = dataColumns(len(section_starts), os.path.basename(summary_file))
	sumDataset.site_order = site_order
	sumDataset.get_all_taus(tau_directory)

	for line_start in section_starts:
		# get list of lines we want to look at
		beginning_line = line_start

		# try to get the next element in the list
		try:
			end_line = section_starts[section_starts.index(line_start)+1] - 1
		except:
			end_line = -1

		# formulating the relevant rowspan
		relevant_list = sum_lines[beginning_line:end_line]

		split_list = [line.split() for line in relevant_list]

		# add
		for line in split_list:
			if len(line) == 12:
				split_list[split_list.index(line)] = ['---'] + line

		for line in split_list:
			if line == []:
				index = split_list.index(line)
				if split_list[index+1] == [] and split_list[index+2] == []:
					break

				first_row = split_list[index+1]
				second_row = split_list[index+2]
				
				# extract the information from the rows
				scan_num = first_row[0]
				day = first_row[1]
				start = first_row[2][0:2]
				end = second_row[2][0:2]
				mixed_day_time = str(2015.+(float(day)+((float(end)+float(start))/2)/24.)/365.)
				source = first_row[3]
				stat_elev = [first_row[5], first_row[6], first_row[7], first_row[8], first_row[9], first_row[10], first_row[11], first_row[12]]
				pre =  [second_row[5], second_row[6], second_row[7], second_row[8], second_row[9], second_row[10], second_row[11], second_row[12]]			
				
				# get opacity and frequency
				tau_list = sumDataset.cycle_through_station_opacities(mixed_day_time)
				print tau_list

				# add them to the class instance
				sumDataset.scan_num.append(scan_num)
				sumDataset.day.append(day)
				sumDataset.start_time.append(float(start)/24.)
				sumDataset.end_time.append(float(end)/24.)
				FMT = '%H:%M:%S'
				sumDataset.length.append(math.fabs((datetime.datetime.strptime(first_row[2], FMT) - datetime.datetime.strptime(second_row[2], FMT)).total_seconds()))
				sumDataset.daytime_mixed.append(mixed_day_time)
				sumDataset.source.append(source)
				sumDataset.station_elevation.append(stat_elev)
				sumDataset.pre_focus_time.append(pre)
				sumDataset.tau.append(tau_list)

	# sumDataset.show_all()
	column_headers = ['DAY', 'START', 'END', 'SOURCE', 'STATION ELEVATIONS', 'PREFOCUS TIME']

	# write the thing to file
	sumDataset.write_to_file(column_headers, "test_output.sum")

	return sumDataset

def date_to_nth_day(date, format='%Y%m%d'):
    date = pandas.to_datetime(date, format=format)
    new_year_day = pandas.Timestamp(year=date.year, month=1, day=1)
    return (date - new_year_day).days + 1