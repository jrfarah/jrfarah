# make the graph for the SGRA date (files located in hub/)

#TODO: string date for each day

#args=hub dir arg2 = source


import matplotlib.pyplot as plt
import pandas as pd
import glob
import sys
import seaborn as sns

# plt.style.use('seaborn')
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams.update({'font.size': 16})
plt.rcParams['axes.linewidth'] = 1.2 #set the value globally

# colors = 'bgrcmykb'
colors = sns.color_palette("hls", 10)

csv_files = glob.glob(sys.argv[1]+"/*.csv")

label_dict = {"CHANDRA":"CHANDRA (X-Ray)", "EHT":"EHT (230 GHz)", "MAGIC":"MAGIC (TeV)", "HESS":"HESS (TeV)", "NUSTAR":"NuSTAR (X-Ray)", "EAVN":"EAVN (43 & 22 GHz)", "SWIFT":"SWIFT (X-Ray)", "VERITAS":"VERITAS (TeV)"}

i = 0.1
c_idx = 0
for df in csv_files:
	print df
	if df.split('/')[-1] == 'ALMA.csv':
		continue
	l = df.split('/')[-1].strip('.csv')
	data = pd.read_csv(df)
	try:
		plt.broken_barh(list(zip(data["Start"].values, (data[" End"] - data["Start"]).values)), (0.95-i, 0.075), label=label_dict[l], color=colors[c_idx])
	except KeyError:
		plt.broken_barh(list(zip(data["Start"].values, (data["End"] - data["Start"]).values)), (0.95-i, 0.075), label=label_dict[l], color=colors[c_idx])
	i+=0.11
	c_idx+=1

# make the ALMA graph inside of the EHT bar
# data = pd.read_csv('hub/ALMA.csv')
# try:
# 	plt.broken_barh(list(zip(data["Start"].values, (data[" End"] - data["Start"]).values)), (0.95-i+0.12, 0.025), color=colors[c_idx+1])
# except KeyError:
# 	plt.broken_barh(list(zip(data["Start"].values, (data["End"] - data["Start"]).values)), (0.95-i+0.12, 0.025), color=colors[c_idx+1])


x = range(108,122, 2)




plt.tick_params(
    axis='y',          # changes apply to the x-axis
    which='both',      # both major and minor ticks are affected
    right=False,      # ticks along the bottom edge are off
    left=False,         # ticks along the top edge are off
    labelleft=False)

plt.gca().xaxis.grid(True)
plt.ylim(0, 1.0)
plt.xlim(108, 120)
plt.xlabel("Day of the Year")
plt.title("{0} Multiwavelength Observation Summary, 2018".format(sys.argv[2]))
plt.legend(loc='center left', bbox_to_anchor=(1, 0.5), markerscale=10, labelspacing=2.2)
plt.xticks(x, ["Apr 18", "Apr 20", "Apr 22", "Apr 24", "Apr 26", "Apr 28", "Apr 30"])
# plt.savefig("OPEN_ME.png", bbox_inches="tight")
plt.show()