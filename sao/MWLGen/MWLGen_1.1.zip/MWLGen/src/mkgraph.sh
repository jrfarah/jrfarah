#!/bin/sh
# this script will walk the user through making a multiwavelength attention summary graph

echo ==============================
echo MWLGEN
echo Written by: Joseph Farah
echo Last updated: June 7, 2018
echo ==============================
echo 
echo 
echo This script will walk you through creating a graph summarizing the multiwavelength attention spans of the global EHT stations.
read -p "Press [ENTER] when you are ready to begin."
echo 
echo
echo
echo First thing we will do is make sure all the datasets are in the right place \(EXCEPT for SWIFT and EHT.\)
echo Make sure there is a folder containing .csvs for each station. The .csv files should be all caps \(ex. CHANDRA.csv\) 
echo and should contain only two columns, formatted like so:
echo Start,End
echo xxxxx,yyyyyy
echo with the dates written in [day of year].[fraction of day]. 
read -p "Is this the case? <y/N> " prompt
if [[ $prompt =~ [yY](es)* ]]
then
	echo Great! What is the name of the directory where all the data files are stored?
	read -p ">>> " hub_dir 
	echo Awesome. You\'re doing great. We\'re going to work with the EHT files now. Where are you storing the .sum files relevant to the run?
	read -p ">>> " sum_dir
	echo And what source are we looking at \(please give me the code, not the full source name\)?
	read -p ">>> " source 
	echo Thanks. I\'m going to look in $sum_dir and pull out the important details relevant to $source.

	python read_sum_script.py $hub_dir $source $sum_dir
	echo Let\'s look inside of $hub_dir for a second. There should be a file called EHT.csv in there. Can you see it?
	ls -l $hub_dir | grep -E --color 'EHT.csv|$'

	read -p "Is this the case? <y/N> " prompt
	if [[ $prompt =~ [yY](es)* ]]
	then
		echo Great! Moving on.
		echo Now we\'re  going to work with the SWIFT files. Follow the instructions in the note to create a file in THIS DIRECTORY called "mwlgen_SWIFT.csv". Once you\'ve done this, let me know.
		read -p "Press [ENTER] when you are ready to continue."
		echo Perfect. I\'m going to look through the SWIFT data and get back to you in less than the time it takes you to read this. 

		python read_swift_script.py $hub_dir
		echo Done! Now there should be a file called SWIFT.csv inside of $hub_dir. Is this the case?
		ls -l $hub_dir | grep -E --color 'SWIFT.csv|$'

		read -p "Is this the case? <y/N> " prompt
		if [[ $prompt =~ [yY](es)* ]]
		then
			echo Yay! I\'m very happy and we\'re almost done! Time for me to make this graph. 
			python make_graph.py $hub_dir $source
			echo All done! Look for a file screaming at you and check to see if it looks the way you expect. Thanks for playing!
		else
			echo Aw man. Something is wrong. Exiting.
		fi

	else
		echo Something is wrong. Exiting.
	fi
else
	echo Please do this first. Exiting.
fi

