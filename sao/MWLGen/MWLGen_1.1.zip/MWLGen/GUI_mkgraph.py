# gui to make the MWL coverage graphs

# TODO:
# -

import PIL.Image
from PIL import ImageDraw 
from PIL import ImageTk
import os
import random
import datetime
import time
# import matplotlib.pyplot as plt
from Tkinter import *
from tkFileDialog import askopenfilename as selectFILE
from tkFileDialog import askdirectory as selectFOLDER
import tkMessageBox as tkmb
import sys
import glob
import subprocess

show_graph = False
hub_dir = ""
sum_dir = ""
swift_dir = ""

main = Tk()


class CreateToolTip(object):
    '''
    create a tooltip for a given widget
    '''
    def __init__(self, widget, text='widget info'):
        self.widget = widget
        self.text = text
        self.widget.bind("<Enter>", self.enter)
        self.widget.bind("<Leave>", self.close)
    def enter(self, event=None):
        x = y = 0
        x, y, cx, cy = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 20
        # creates a toplevel window
        self.tw = Toplevel(self.widget)
        # Leaves only the label and removes the app window
        self.tw.wm_overrideredirect(True)
        self.tw.wm_geometry("+%d+%d" % (x, y))
        label = Label(self.tw, text=self.text, justify='left',
                       background='yellow', relief='solid', borderwidth=1,
                       font=("times", "8", "normal"))
        label.pack(ipadx=1)
    def close(self, event=None):
        if self.tw:
            self.tw.destroy()

# def createToolTip(widget, text):
#     toolTip = ToolTip(widget)
#     def enter(event):
#         toolTip.showtip(text)
#     def leave(event):
#         toolTip.hidetip()
#     widget.bind('<Enter>', enter)
#     widget.bind('<Leave>', leave)

def redraw_graph():
    if show_graph == True:
        # redraw graph
        print "I'd redraw the graph here but whatever"

def dummy():
    print 'test'

def pick_filepath(var, label, check):
    global hub_dir, sum_dir, swift_dir
    var = selectFILE()
    row    = label.grid_info()['row']      # Row of the button
    column = label.grid_info()['column']
    program_print("Added filepath: "+var)
    if check == "SWIFT":
        print check
        ready_status = check_swift(var)
        swift_dir = var
    program_print(check+" "+str(ready_status))
    if ready_status == True:
        label = Label(main, text="READY", bg="green", width=30)
        label.grid(row=row, column=column)
        program_print("$hub (excluding SWIFT and EHT) is ready to go")
    if ready_status == False:
        label = Label(main, text="NOT READY", bg="red", width=30)
        label.grid(row=row, column=column)
        program_print("One of your files is improperly formatted.")


def pick_folderpath(var, label, check):
    global hub_dir, sum_dir, swift_dir
    var = selectFOLDER()
    row    = label.grid_info()['row']      # Row of the button
    column = label.grid_info()['column']
    program_print("Added folderpath: "+var)
    if check == "hub":
        ready_status = check_csv(var)
        hub_dir = var
    if check == "sum":
        ready_status = check_sum(var)
        sum_dir = var
    if check == "SWIFT":
        print check
        ready_status = check_swift(var)
        swift_dir = var
    program_print(check+" "+str(ready_status))
    if ready_status == True:
        label = Label(main, text="READY", bg="green", width=30)
        label.grid(row=row, column=column)
        program_print("$hub (excluding SWIFT and EHT) is ready to go")
    if ready_status == False:
        program_print("One of your files is improperly formatted.")
        label = Label(main, text="NOT READY", bg="red", width=30)
        label.grid(row=row, column=column)

def program_print(message):
    global program_ouput
    program_output.see(END)
    program_output.insert(END, str(message)+'\n')
    program_output.see(END) 

def check_csv(path):
    sum_files = glob.glob(path+"/*.csv")
    for _file in sum_files:
        program_print("Examining data file: "+_file)
        ready_status = True
        with open(_file, "r") as s:
            lines = s.readlines()
            if lines[0].strip() not in ["Start,End", "Start, End", "Start ,End", "Start , End"]:
                program_print("Found an improperly formatted file! Problem is with: [column headers] in file {0}".format(_file))
                program_print(lines[0])
                ready_status = False
            for line in lines:
                if lines.index(line) == 0:
                    continue
                if len(line.split(',')) != 2:
                    program_print("Found an improperly formatted file! Problem is with: [there are more than two elements per line in file: "+_file+"]")
                    ready_status = False
                if float(line.split(',')[0]) > 367 or float(line.split(',')[1]) > 367:
                    program_print("Found an improperly formatted file! Problem is with: [the data has a value greater than 367] in file {0}".format(_file))
                    ready_status = False

    return ready_status

def check_sum(path):
    sum_files = glob.glob(path+"/*.sum")
    ready_status = True
    if len(sum_files) == 0:
        program_print("There are no SUM files in this folder!")
        ready_status = False
    return ready_status

def check_swift(path):
    ready_status = True
    with open(path, "r") as swift:
        lines = swift.readlines()

    if len(lines) == 0:
        ready_status = False

    # for line in lines:
    #     if len(line.strip(',').split(',')) != 2:
    #         print line.strip(',').split(',')
    #         program_print("Found an improperly formatted file! Problem is with: [there are more than two elements per line in file: "+path+"]")
    #         ready_status = False


    return ready_status

def intro():
    top = Toplevel()
    top.title('Welcome')
    m = Message(top, text='This software was made by Joseph Farah, a Smithsonian Fellow at the SAO. Please credit any figures made with this with "Made with MWLGen, software by J. Farah." Special thanks to Dr. Michael Johnson. By continuing you acknowledge and agree to this condition.\n\n\n For any questions, concerns, or suggestions, feel free to shoot me an email at joseph.farah@cfa.harvard.edu.', padx=20, pady=20)
    m.grid(row=0,column=0)
    # top.after(500, top.destroy)
    b = Button(top, text="CLICK TO ACKNOWLEDGE THE ABOVE", highlightbackground='green', command=lambda:kill(top), width=40, fg='blue')
    top.lift(aboveThis=main)
    top.wm_attributes("-topmost", 1)
    b.grid(row=1, column=0)

    # def flash():
    # b.config(bg='red')
    # time.sleep(0.5)
    # b.config(bg='green')
    # time.sleep(0.5)
    # flash()

    # flash()
    top.mainloop()

def kill(top):
    top.destroy()

def make_graph(hd, swd, sumd, src):
    print "FILEPATHS: ", hd, swd, sumd, src.get()
    program_print("Beginning to make the graph.\nRunning read_swift.py")
    command = "python src/read_swift_script.py  {0} {1}".format(hd, swd)
    print command
    error = subprocess.check_output(command, shell=True)
    program_print(error)
    program_print("Running read_sum.py")
    command = "python src/read_sum_script.py {0} {1} {2}".format(sumd, src.get(), sumd)
    error = subprocess.check_output(command, shell=True)
    program_print(error)
    program_print("Running make_graph.py")
    command = "python src/make_graph.py {0} {1}".format(hd, src.get())
    error = subprocess.check_output(command, shell=True)
    program_print(error)

def intro():
    top = Toplevel()
    top.title('Welcome')
    m = Message(top, text='This software was made by Joseph Farah, a Smithsonian Fellow at the SAO. Please credit any figures made with this with "Made with MWLGen, software by J. Farah." Special thanks to Dr. Michael Johnson. By continuing you acknowledge and agree to this condition.\n\n\n For any questions, concerns, or suggestions, feel free to shoot me an email at joseph.farah@cfa.harvard.edu.', padx=20, pady=20)
    m.grid(row=0,column=0)
    # top.after(500, top.destroy)
    b = Button(top, text="CLICK TO ACKNOWLEDGE THE ABOVE", highlightbackground='green', command=lambda:kill(top), width=40, fg='blue')
    top.lift(aboveThis=main)
    top.wm_attributes("-topmost", 1)
    b.grid(row=1, column=0)

    # def flash():
    # b.config(bg='red')
    # time.sleep(0.5)
    # b.config(bg='green')
    # time.sleep(0.5)
    # flash()

    # flash()
    top.mainloop()

# UI elements
#buttons
hub_button = Button(main, text="$HUB", command=lambda:pick_folderpath(hub_dir, hub_status, "hub"), width=30)
hub_button.grid(row=0,column=0)
CreateToolTip(hub_button, "This is a tooltip")
sum_button = Button(main, text="$SUM", command=lambda:pick_folderpath(sum_dir, sum_label, "sum"), width=30)
sum_button.grid(row=1,column=0)
swift_button = Button(main, text="$SWIFT", command=lambda:pick_filepath(swift_dir, swift_label, "SWIFT"), width=30)
swift_button.grid(row=2,column=0)
# src_button = Button(main, text="$SRC", command=dummy, width=30)
# src_button.grid(row=3,column=0)
# Create a Tkinter variable
src = StringVar(main)
 
# Dictionary with options
choices = { 'SGRA', 'M87'}
src.set('SGRA') # set the default option
 
popupMenu = OptionMenu(main, src, *choices)
popupMenu.grid(row=3, column=0)

make_graph_button = Button(main, text="MAKE GRAPH", command=lambda:make_graph(hub_dir, swift_dir, sum_dir, src))
make_graph_button.grid(row=0,column=2,columnspan=4)

# status labels
hub_status = Label(main, text="NOT READY", bg="red", width=30)
hub_status.grid(row=0,column=1)
sum_label = Label(main, text="NOT READY", bg="red", width=30)
sum_label.grid(row=1,column=1)
swift_label = Label(main, text="NOT READY", bg="red", width=30)
swift_label.grid(row=2,column=1)
src_label = Label(main, text="READY", bg="green", width=30)
src_label.grid(row=3,column=1)

# printout display
program_output = Text(main, bg = "black", fg = "white", insertbackground = "white",tabs = ("1c"), height=6)
program_output.grid(row=4,column=0, columnspan=2, rowspan=2)

menubar = Menu(main)
help_menu = Menu(menubar, tearoff=0)
help_menu.add_command(label='Tutorial', command=lambda:dummy)

menubar.add_cascade(label="Help", menu=help_menu)
main.config(menu=menubar)

main.after(0, intro)
main.wm_title("MWLGen -- J. Farah")
main.mainloop()